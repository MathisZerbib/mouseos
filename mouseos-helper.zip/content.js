// Watches the streaming page and tells the helper (background.js) what it asks;
// presses the site's own button when the phone answers.
"use strict";

(function () {
  var sent = "";

  function report(force) {
    var found = MouseOsDetect.find(document);
    var key = found ? [found.kind, found.site, found.title || "", found.video || "", (found.videos || []).map(function (v) { return v.id; }).join()].join("|") : "";
    if (!force && key === sent) return;
    sent = key;
    try {
      chrome.runtime.sendMessage(found
        ? { type: "prompt", kind: found.kind, site: found.site, title: found.title || null, video: found.video || null, videos: found.videos || [] }
        : { type: "prompt", kind: null, site: null });
    } catch (e) {
      // The extension was updated or removed: this old copy of the script has nobody to talk to.
    }
  }

  var pending = false;
  new MutationObserver(function () {
    if (pending) return;
    pending = true;
    setTimeout(function () { pending = false; report(false); }, 250);
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden", "aria-hidden"] });

  // What plays (YouTube, YouTube Music), once a second: the phone's music widget.
  var hadMedia = false;
  function reportMedia() {
    var m = MouseOsDetect.media(document);
    if (!m && !hadMedia) return;
    hadMedia = !!m;
    try { chrome.runtime.sendMessage(m ? Object.assign({ type: "media" }, m) : { type: "media" }); } catch (e) {}
  }

  setInterval(function () { report(false); reportMedia(); }, 1000);
  // Now and then even unchanged: wakes the helper if the browser put it to sleep.
  setInterval(function () { report(true); }, 15000);
  report(true);

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.type === "control") {
      MouseOsDetect.control(document, msg.action);
      setTimeout(reportMedia, 300);
      return;
    }
    if (!msg || msg.type !== "answer") return;
    var found = MouseOsDetect.find(document);
    if (msg.video && found && found.kind === "NEXT_VIDEO") {
      // One of the other suggestions: its own link on the page, else straight to it.
      var link = MouseOsDetect.videoLink(document, msg.video);
      if (link) MouseOsDetect.press(link);
      else if (/^[A-Za-z0-9_-]{11}$/.test(msg.video)) location.assign("/watch?v=" + msg.video);
    } else if (found && found.kind === msg.kind) {
      MouseOsDetect.press(found.button);
    }
    setTimeout(function () { report(false); }, 300);
  });

  window.addEventListener("pagehide", function () {
    try { chrome.runtime.sendMessage({ type: "prompt", kind: null, site: null }); } catch (e) {}
    try { chrome.runtime.sendMessage({ type: "media" }); } catch (e) {}
  });
})();
