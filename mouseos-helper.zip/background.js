// The link to MouseOS on this computer: one WebSocket to its server, carrying
// what the streaming tabs ask (content.js), what YouTube plays, and the phone's answers and keys back.
"use strict";

var SERVER = "ws://127.0.0.1:53317/browser";
// MouseOS not running: try again, less and less often (Chrome lists every refused try as an error).
var RETRY_MIN_MS = 5000;
var RETRY_MAX_MS = 60000;
var retryMs = RETRY_MIN_MS;
var PING_MS = 20000;

var ws = null;
var retry = null;
var ping = null;
// tabId → { kind, site, title, video, videos, key, at }: what each streaming tab asks right now.
var prompts = new Map();
var lastSent = null;
// tabId → { site, title, artist, art, playing, position, duration, since }: what each tab plays (YouTube).
var media = new Map();

function browserName() {
  var ua = navigator.userAgent;
  if (/Firefox\//.test(ua)) return "Firefox";
  var brands = (navigator.userAgentData && navigator.userAgentData.brands) || [];
  var named = brands.map(function (b) { return b.brand; }).filter(function (b) { return !/Chromium|Not.?A.?Brand/i.test(b); });
  if (named.length) return named[0].replace("Google ", "");
  if (/Edg\//.test(ua)) return "Edge";
  if (/OPR\//.test(ua)) return "Opera";
  return "Chrome";
}

function newest() {
  var best = null;
  prompts.forEach(function (p) { if (!best || p.at > best.at) best = p; });
  return best;
}

function send(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function sendPrompt(force) {
  var p = newest();
  var key = p ? p.key : "";
  if (!force && key === lastSent) return;
  lastSent = key;
  send(p
    ? { type: "prompt", kind: p.kind, site: p.site, title: p.title || undefined, video: p.video || undefined, videos: p.videos.length ? p.videos : undefined }
    : { type: "prompt" });
}

// The tab the phone's music widget shows: the one playing that started last, else the one paused last.
function mediaTab() {
  var best = null;
  media.forEach(function (m, tabId) {
    if (!best || (m.playing && !best.m.playing) || (m.playing === best.m.playing && m.since > best.m.since)) best = { tabId: tabId, m: m };
  });
  return best;
}

function sendMedia() {
  var t = mediaTab();
  if (!t) { send({ type: "media" }); return; }
  var m = t.m;
  send({ type: "media", site: m.site, title: m.title, artist: m.artist, art: m.art, playing: m.playing, position: m.position, duration: m.duration });
}

// The phone's "show tab" key: that tab in front of its window, its window in front of the screen.
function showTab(tabId) {
  chrome.tabs.update(tabId, { active: true }).then(function (tab) {
    return chrome.windows.get(tab.windowId).then(function (w) {
      // A minimized window comes back as it was; focusing alone may leave it in the Dock / taskbar.
      return chrome.windows.update(w.id, w.state === "minimized" ? { state: "normal", focused: true } : { focused: true });
    });
  }).catch(function () {});
}

function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  clearTimeout(retry);
  try {
    ws = new WebSocket(SERVER);
  } catch (e) {
    later();
    return;
  }
  ws.onopen = function () {
    retryMs = RETRY_MIN_MS;
    send({ type: "hello", browser: browserName(), version: chrome.runtime.getManifest().version });
    sendPrompt(true);
    sendMedia();
    clearInterval(ping);
    // Traffic keeps the browser from putting the helper to sleep while MouseOS is on.
    ping = setInterval(function () { send({ type: "ping" }); }, PING_MS);
  };
  ws.onmessage = function (e) {
    var msg;
    try { msg = JSON.parse(e.data); } catch (err) { return; }
    if (msg.type === "control") {
      var t = mediaTab();
      if (t) chrome.tabs.sendMessage(t.tabId, { type: "control", action: msg.action }).catch(function () {});
      return;
    }
    if (msg.type === "show") {
      var s = mediaTab();
      if (s) showTab(s.tabId);
      return;
    }
    if (msg.type !== "answer") return;
    var target = null;
    prompts.forEach(function (p, tabId) { if (p.kind === msg.kind && (!target || p.at > target.at)) target = { tabId: tabId, at: p.at }; });
    if (target) chrome.tabs.sendMessage(target.tabId, { type: "answer", kind: msg.kind, video: msg.video || undefined }).catch(function () {});
  };
  ws.onclose = function () {
    ws = null;
    clearInterval(ping);
    later(); // MouseOS not running (yet): try again
  };
}

function later() {
  clearTimeout(retry);
  retry = setTimeout(connect, retryMs);
  retryMs = Math.min(retryMs * 2, RETRY_MAX_MS);
}

chrome.runtime.onMessage.addListener(function (msg, sender) {
  if (msg && msg.type === "media" && sender.tab) {
    var was = media.get(sender.tab.id);
    if (msg.title) {
      var since = was && was.playing === !!msg.playing && was.title === msg.title ? was.since : Date.now();
      media.set(sender.tab.id, {
        site: msg.site, title: msg.title, artist: msg.artist || undefined, art: msg.art || undefined,
        playing: !!msg.playing, position: msg.position, duration: msg.duration || undefined, since: since,
      });
    } else if (!media.delete(sender.tab.id)) return;
    connect();
    sendMedia();
    return;
  }
  if (!msg || msg.type !== "prompt" || !sender.tab) return;
  var tabId = sender.tab.id;
  var old = prompts.get(tabId);
  if (msg.kind) {
    var videos = Array.isArray(msg.videos) ? msg.videos : [];
    var key = [msg.kind, msg.site, msg.title || "", msg.video || "", videos.map(function (v) { return v.id; }).join()].join("|");
    if (!old || old.key !== key) {
      prompts.set(tabId, { kind: msg.kind, site: msg.site, title: msg.title || null, video: msg.video || null, videos: videos, key: key, at: Date.now() });
    }
  } else {
    prompts.delete(tabId);
  }
  connect();
  sendPrompt(false);
});

chrome.tabs.onRemoved.addListener(function (tabId) {
  if (prompts.delete(tabId)) sendPrompt(false);
  if (media.delete(tabId)) sendMedia();
});

chrome.tabs.onUpdated.addListener(function (tabId, info) {
  if (info.status === "loading" && prompts.delete(tabId)) sendPrompt(false);
});

chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(connect);
connect();
