// What the streaming site asks right now, read from the page itself.
// Shared by content.js (in the browser) and test/detect.test.js (Node + jsdom).
"use strict";

var MouseOsDetect = (function () {
  var SITES = [
    [/(^|\.)netflix\.com$/, "Netflix"],
    [/(^|\.)disneyplus\.com$/, "Disney+"],
    [/(^|\.)(max|hbomax)\.com$/, "Max"],
    [/(^|\.)canalplus\.com$/, "Canal+"],
    [/(^|\.)(primevideo\.com|amazon\.[a-z.]+)$/, "Prime Video"],
    [/(^|\.)paramountplus\.com$/, "Paramount+"],
    [/^tv\.apple\.com$/, "Apple TV+"],
    [/(^|\.)crunchyroll\.com$/, "Crunchyroll"],
    [/(^|\.)youtube\.com$/, "YouTube"],
  ];

  // The sites' own buttons, when we know them: exact, whatever the language.
  var KNOWN = {
    NEXT_EPISODE: [
      '[data-uia="next-episode-seamless-button"]',
      '[data-uia="next-episode-seamless-button-draining"]',
      '[data-testid="up-next-play-button"]',
      '[data-testid="player-ux-up-next-button"]',
      ".atvwebplayersdk-nextupcard-button",
    ],
    STILL_WATCHING: ['[data-uia="interrupt-autoplay-continue"]'],
  };

  // YouTube at the end of a video: the autoplay countdown's "up next", else the
  // first video of the end-screen wall (autoplay off). [button, its title].
  var YOUTUBE_NEXT = [
    [".ytp-autonav-endscreen-upnext-play-button", ".ytp-autonav-endscreen-upnext-title"],
    [".ytp-autonav-endscreen-upnext-container", ".ytp-autonav-endscreen-upnext-title"],
    ["a.ytp-videowall-still", ".ytp-videowall-still-info-title"],
  ];

  // Otherwise the words, in English, French, Spanish, German, Italian and Portuguese.
  var NEXT = /(next episode|play next|épisode suivant|siguiente episodio|próximo episodio|nächste folge|nächste episode|prossimo episodio|episodio successivo|próximo episódio|episódio seguinte)/i;
  var STILL_ASKED = /(still watching|are you still there|continue watching\?|video paused|vidéo en pause|vídeo en pausa|video pausiert|video in pausa|vídeo pausado|toujours (là|en train de regarder)|regardez-vous toujours|sigues viendo|todavía estás viendo|schaust du (noch|weiter)|siehst du (noch|dir)|stai ancora guardando|sei ancora (lì|li)|ainda está (assistindo|a ver|aí)|continuas a ver)/i;
  var CONTINUE = /^(continue watching|keep watching|continue|yes|continuer( la lecture| à regarder)?|poursuivre( la lecture)?|oui|seguir viendo|continuar( viendo| assistindo| a ver)?|sí|weiterschauen|weiter ansehen|weiter|ja|continua( a guardare| la visione)?|sì|sim)$/i;

  var CLICKABLE = 'button, [role="button"], a[href]';

  function site(hostname) {
    for (var i = 0; i < SITES.length; i++) if (SITES[i][0].test(hostname)) return SITES[i][1];
    return null;
  }

  function visible(el) {
    if (!el || el.hidden || el.disabled || el.getAttribute("aria-hidden") === "true") return false;
    var win = el.ownerDocument.defaultView;
    for (var n = el; n && n.nodeType === 1; n = n.parentElement) {
      var cs = win.getComputedStyle(n);
      if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") return false;
    }
    var r = el.getBoundingClientRect();
    // jsdom has no layout (every rect is 0×0): there, style is the whole answer.
    return r.width > 0 || r.height > 0 || !win.document.documentElement.getBoundingClientRect().width;
  }

  // The words people read on the button. Not aria-label: the player's own ⏭ icon
  // (always in the control bar) is labelled "Next episode" too, and is no question.
  function label(el) {
    var text = (el.textContent || "").replace(/\s+/g, " ").trim();
    return text.length <= 60 ? text : "";
  }

  function known(doc, kind) {
    var list = KNOWN[kind];
    for (var i = 0; i < list.length; i++) {
      var el = doc.querySelector(list[i]);
      if (visible(el)) return el;
    }
    return null;
  }

  function byWords(doc, re) {
    var els = doc.querySelectorAll(CLICKABLE);
    for (var i = 0; i < els.length; i++) {
      var l = label(els[i]);
      if (l && re.test(l) && visible(els[i])) return els[i];
    }
    return null;
  }

  // "Are you still watching?" is a sentence on screen, not a button: find it, then its button.
  function stillWatching(doc) {
    var hit = known(doc, "STILL_WATCHING");
    if (hit) return hit;
    var nodes = doc.querySelectorAll("h1, h2, h3, h4, p, div, span, [role='dialog'], [role='alertdialog']");
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.children.length > 3) continue; // the sentence itself, not a whole page section
      var t = (n.textContent || "").replace(/\s+/g, " ").trim();
      if (t.length > 120 || !STILL_ASKED.test(t) || !visible(n)) continue;
      // The answer button sits in the same dialog: climb a few levels and look there.
      var scope = n;
      for (var up = 0; up < 5 && scope.parentElement; up++) {
        scope = scope.parentElement;
        var btn = byWords(scope, CONTINUE);
        if (btn) return btn;
      }
    }
    return null;
  }

  // A YouTube video id, from a link or the page's own address.
  function videoId(href) {
    var m = /[?&]v=([A-Za-z0-9_-]{11})(?![A-Za-z0-9_-])/.exec(href || "");
    return m ? m[1] : null;
  }

  function text(el) {
    return el ? (el.textContent || "").replace(/\s+/g, " ").trim() : "";
  }

  var SUGGESTIONS_MAX = 16;
  // A suggestion's card in the column on the right (old and new layouts) and on the end screen.
  var CARD = "ytd-compact-video-renderer, ytd-compact-radio-renderer, yt-lockup-view-model, ytd-rich-item-renderer, a.ytp-videowall-still";

  /**
   * The other videos YouTube suggests: the end screen's wall, then the column on
   * the right. [{ id, title, channel? }], without [skip] (what plays next) and
   * without the video that just ended.
   */
  function suggestions(doc, skip) {
    var out = [];
    var seen = {};
    seen[videoId(doc.location ? doc.location.search : "")] = true;
    if (skip) seen[skip] = true;
    var links = doc.querySelectorAll('a.ytp-videowall-still[href], #secondary a[href*="watch?v="], #related a[href*="watch?v="]');
    for (var i = 0; i < links.length && out.length < SUGGESTIONS_MAX; i++) {
      var id = videoId(links[i].getAttribute("href"));
      if (!id || seen[id]) continue;
      var card = links[i].closest(CARD) || links[i].parentElement;
      var title = text(card.querySelector(".ytp-videowall-still-info-title, #video-title, h3")) || (links[i].getAttribute("title") || "").trim();
      if (!title) continue; // a bare thumbnail link: its card's title link comes next
      var by = text(card.querySelector(".ytp-videowall-still-info-author, ytd-channel-name #text, ytd-channel-name, [class*='metadata-text']"));
      by = by.split(/\s+[•·]\s+/)[0];
      seen[id] = true;
      var v = { id: id, title: title.slice(0, 100) };
      if (by && by.length <= 40) v.channel = by;
      out.push(v);
    }
    return out;
  }

  /** The suggestion [id]'s own link on the page (the site then opens it its own way), or null. */
  function videoLink(doc, id) {
    if (!/^[A-Za-z0-9_-]{11}$/.test(id || "")) return null;
    var links = doc.querySelectorAll('a[href*="' + id + '"]');
    for (var i = 0; i < links.length; i++) if (videoId(links[i].getAttribute("href")) === id) return links[i];
    return null;
  }

  function youtubeNext(doc) {
    for (var i = 0; i < YOUTUBE_NEXT.length; i++) {
      var els = doc.querySelectorAll(YOUTUBE_NEXT[i][0]);
      for (var j = 0; j < els.length; j++) {
        if (!visible(els[j])) continue;
        // The title sits inside the tile, or beside the play button in the countdown card.
        var card = els[j].closest(".ytp-autonav-endscreen-upnext-container") || els[j];
        var t = card.querySelector(YOUTUBE_NEXT[i][1]) || doc.querySelector(YOUTUBE_NEXT[i][1]);
        var title = text(t).slice(0, 80);
        var link = els[j].matches("a[href]") ? els[j] : card.querySelector('a[href*="watch?v="]');
        return { button: els[j], title: title || null, video: link ? videoId(link.getAttribute("href")) : null };
      }
    }
    return null;
  }

  /**
   * The question on screen, with the button that answers it:
   * { kind: "NEXT_EPISODE" | "NEXT_VIDEO" | "STILL_WATCHING", site, button, title? }, or null.
   * YouTube's NEXT_VIDEO adds what plays next ({ video: id }) and the other
   * suggestions ({ videos: [{ id, title, channel? }] }).
   * Only while a video plays on a known streaming site.
   */
  function find(doc) {
    var name = site(doc.location ? doc.location.hostname : "");
    if (!name || !doc.querySelector("video")) return null;
    var still = stillWatching(doc);
    if (still) return { kind: "STILL_WATCHING", site: name, button: still };
    if (name === "YouTube") {
      var yt = youtubeNext(doc);
      if (!yt) return null;
      return { kind: "NEXT_VIDEO", site: name, button: yt.button, title: yt.title, video: yt.video, videos: suggestions(doc, yt.video) };
    }
    var next = known(doc, "NEXT_EPISODE") || byWords(doc, NEXT);
    if (next) return { kind: "NEXT_EPISODE", site: name, button: next };
    return null;
  }

  /** A real-looking click: some players listen to pointer events, not just click. */
  function press(el) {
    var win = el.ownerDocument.defaultView;
    var opts = { bubbles: true, cancelable: true, view: win };
    ["pointerdown", "mousedown", "pointerup", "mouseup"].forEach(function (type) {
      var Ctor = type.indexOf("pointer") === 0 && win.PointerEvent ? win.PointerEvent : win.MouseEvent;
      el.dispatchEvent(new Ctor(type, opts));
    });
    el.click();
  }

  /**
   * What YouTube or YouTube Music plays in this tab, for the phone's music widget:
   * { site, title, artist?, art?, playing, position, duration? } (milliseconds), or null.
   * The page's own media session first (what the OS media keys see), else the page.
   */
  function media(doc) {
    var host = doc.location ? doc.location.hostname : "";
    var music = host === "music.youtube.com";
    if (!music && !(/(^|\.)youtube\.com$/.test(host) && /^\/(watch|shorts\/)/.test(doc.location.pathname))) return null;
    var vid = doc.querySelector("video.html5-main-video") || doc.querySelector("video");
    if (!vid || !(vid.currentSrc || vid.src) || vid.ended) return null;
    var nav = doc.defaultView && doc.defaultView.navigator;
    var meta = nav && nav.mediaSession && nav.mediaSession.metadata;
    var title = (meta && meta.title) || text(doc.querySelector("h1.ytd-watch-metadata, #title h1, ytmusic-player-bar .title")) ||
      (doc.title || "").replace(/^\(\d+\)\s*/, "").replace(/\s*-\s*YouTube( Music)?$/, "");
    if (!title) return null;
    var artist = (meta && meta.artist) || text(doc.querySelector("ytd-watch-metadata #owner ytd-channel-name a, #owner #channel-name a, ytd-channel-name a")) || null;
    var art = null;
    var works = (meta && meta.artwork) || [];
    for (var i = 0; i < works.length; i++) {
      // The biggest: the phone shrinks it.
      var w = parseInt(String(works[i].sizes || "").split("x")[0], 10) || 0;
      if (/^https:/.test(works[i].src || "") && (!art || w > art.w)) art = { src: works[i].src, w: w };
    }
    art = art ? art.src : null;
    if (!art) {
      var id = videoId(doc.location.search) || (/^\/shorts\/([A-Za-z0-9_-]{11})/.exec(doc.location.pathname) || [])[1];
      if (id) art = "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg";
    }
    var out = {
      site: music ? "YouTube Music" : "YouTube",
      title: String(title).slice(0, 120),
      playing: !vid.paused,
      position: Math.round((vid.currentTime || 0) * 1000),
    };
    if (artist) out.artist = String(artist).slice(0, 80);
    if (art) out.art = art;
    if (isFinite(vid.duration) && vid.duration > 0) out.duration = Math.round(vid.duration * 1000);
    return out;
  }

  /** The phone's music keys on YouTube: "PLAY_PAUSE", "NEXT", "PREVIOUS". */
  function control(doc, action) {
    var vid = doc.querySelector("video.html5-main-video") || doc.querySelector("video");
    if (!vid) return false;
    var music = doc.location.hostname === "music.youtube.com";
    function button(sel) {
      var el = doc.querySelector(sel);
      if (el && visible(el)) { press(el); return true; }
      return false;
    }
    if (action === "PLAY_PAUSE") {
      if (vid.paused) { var p = vid.play(); if (p && p.catch) p.catch(function () {}); } else vid.pause();
      return true;
    }
    if (action === "NEXT") return button(music ? "ytmusic-player-bar .next-button" : ".ytp-next-button");
    if (action === "PREVIOUS") {
      // Back to the start, like every player; at the start, the previous one when there is one.
      if (vid.currentTime > 3) { vid.currentTime = 0; return true; }
      if (button(music ? "ytmusic-player-bar .previous-button" : ".ytp-prev-button")) return true;
      vid.currentTime = 0;
      return true;
    }
    return false;
  }

  return { find: find, press: press, site: site, videoLink: videoLink, media: media, control: control };
})();

if (typeof module !== "undefined") module.exports = MouseOsDetect;
